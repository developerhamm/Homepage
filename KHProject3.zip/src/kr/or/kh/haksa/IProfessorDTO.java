package kr.or.kh.haksa;

public interface IProfessorDTO {
	public abstract String getSubject();
	public abstract void setSubject(String subject);
}
